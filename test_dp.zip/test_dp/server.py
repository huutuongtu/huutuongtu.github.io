from flask import Flask, jsonify, request
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
app = Flask(name)


@app.route("/predict", methods=['POST'])
def do_prediction():
    json = request.get_json()
    #loading saved model here in this python file
    model = joblib.load('model/price_model.pkl')
    #creating data frame of JSON data
    df = pd.DataFrame(json, index=[0])
    #performing preprocessing steps
    scaler = StandardScaler()
    scaler.fit(df)

    x_scaled = scaler.transform(df)

    x_scaled = pd.DataFrame(x_scaled, columns=df.columns)
    y_predict = model.predict(x_scaled)

    res = {"Predict": y_predict[0]}
    return jsonify(res)

# if name == "main":
# app.run()
app.run(host='0.0.0.0')